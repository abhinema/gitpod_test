import sublime, sublime_plugin
import datetime, getpass
from multiprocessing.connection import Client
import time
import re
#import getpass

import os
import platform

import subprocess
import sys
import time
from json import loads, dumps
import asyncio

global p1

AUTOCOMPLETE_CHAR_LIMIT = 100000
ATTRIBUTION_ELEMENT = "अ"
PREFERENCES_PATH = "Preferences.sublime-settings"


###################################################################################
# AutoCode Process Class
###################################################################################
class AutoCodeProcess:
    def __init__(self):
        self.autocode_proc = None


    def init_autocode(self, inheritStdio=False, additionalArgs=[]):
        self.autocode_proc = subprocess.Popen(["python", '/home/abhi/.config/sublime-text/Packages/User/auto_coding/interact.py'],
                          stdin=subprocess.PIPE, 
                          stdout=subprocess.PIPE,
                          stderr=subprocess.STDOUT,
                          shell=False)
        result = ""
        print("Auto_code Plugin Status: Loading")
        while(result != "Success\n"):
            result = self.autocode_proc.stdout.readline()
            result = str(result, "UTF-8")
            print("Rx:", result)

            result = loads(result)
            result = result["Output"]
            result = result["status"]

            print("Auto_code Plugin Status:", result)
        print("Auto_code Plugin Status: Loaded")                       
        return self.autocode_proc
                          
    def restart_autocode_proc(self):
        if self.autocode_proc is not None:
            try:
                self.autocode_proc.terminate()
            except Exception:  # pylint: disable=W0703
                pass
        self.autocode_proc = self.init_autocode()                          

    def data_processing(self, str1):
        # Check if autocode process is running or not
        # if not then restart
        if self.autocode_proc is None:
            self.restart_autocode_proc()
        if self.autocode_proc.poll():
            print("Autocode subprocess is dead")
            if self.num_restarts < MAX_RESTARTS:
                print("Restarting it...")
                self.num_restarts += 1
                self.restart_autocode_proc()
            else:
                return None
                
        # Start Auto Code Processing by Preparing data to send 
        # to another process.        
        list1 = []
        try:
            print("=============================\n")
            #print("str:---> ",str1)
            #p1.stdin.write(bytes("Abhishek\n","UTF-8"))
            req = dumps(get_data(str1, 5))
            req += '\n'
            print("Data Tx:",req)
            self.autocode_proc.stdin.write(bytes(req, "UTF-8"))
            self.autocode_proc.stdin.flush()

            result = self.autocode_proc.stdout.readline()
            result = str(result, "UTF-8")
            print("Rx str: ",result)
            
            if(result == "1Done\n"):
                return result

            print("Got Data len: ",len(result))    
            print("Result: ",result)

            if(len(result) != 0):
                result = loads(result)
                #print("type: ", type(result))

                #result = result["Output"]
                #result = result["status"]
                if(result["status"] == "success"):
                    print("=============================\n")
                    
                    print("Input: ",''.join(result["input"]))

                    result = result["predict"]
                    print("op1: ",result["op1"])
                    print("op2: ",result["op2"])
                    print("op3: ",result["op3"])
                    print("op4: ",result["op4"])
                    print("op5: ",result["op5"])                                
                    print("=============================\n")
                    list1.append(result["op1"])  
                    list1.append(result["op2"])  
                    list1.append(result["op3"])  
                    list1.append(result["op4"])  
                    list1.append(result["op4"])
                    
                    completions = [
                    sublime.CompletionItem(
                        listToString(r),
                        annotation="abhishek-suggest",
                        completion="{}$0{}".format(
                                format_final_string(str1,listToString(r)), ""
                            ),
                        completion_format=sublime.COMPLETION_FORMAT_SNIPPET,
                        kind=(
                            sublime.KIND_ID_COLOR_REDISH,
                            ATTRIBUTION_ELEMENT,
                            "22%",
                        ),
                    )
                    for r in list1
                ]
            return completions
            
        except (BrokenPipeError, IOError):
            print ('BrokenPipeError caught!!!', file = sys.stderr)
            # Python flushes standard streams on exit; redirect remaining output
            # to devnull to avoid another BrokenPipeError at shutdown
            devnull = os.open(os.devnull, os.O_WRONLY)
            os.dup2(devnull, sys.stdout.fileno())
            sys.exit(1)  # Python exits with error code 1 on EPIPE        
   
global autocode_proc
keystroke = ""
#print("###autocode: starting###")
autocode_proc = AutoCodeProcess()  

###################################################################################
# Helper Functions
###################################################################################

def lastWord(string):
   
    # split by space and converting
    # string to list and
    lis = list(string.split(" "))
     
    # length of list
    length = len(lis)
     
    # returning last element in list
    return lis[length-1]  

def get_data(str, beam_num):
    request = {
        "Auto-Code": {
            "stringchk": str,
            "beam_search": beam_num,
        }
    }
    return request

# Function to convert
def listToString(s):
	
	# initialize an empty string
	str1 = ""
	
	# traverse in the string
	for ele in s:
		str1 += ele
	
	# return string
	#print("Api Call:",str1) 
	return str1

def escape_tab_stop_sign(value):
    return re.sub(r"\$", "\\$", value)

def format_final_string(ori, gen):
    print("ORI--> ",listToString(ori.splitlines()[-1:]))
    print("gen--> ",gen)
    str = gen.replace(listToString(ori.splitlines()[-1:]),"")
    print("Replacement--> ",str)
    return str
"""    
def data_processing(str1):
    list1 = []
    try:
        print("=============================\n")
        print("str:---> ",str1)
        #p1.stdin.write(bytes("Abhishek\n","UTF-8"))
        req = dumps(get_data(str1, 5))
        req += '\n'
        print("Data Tx:",req)
        self.autocode_proc.stdin.write(bytes(req, "UTF-8"))
        self.autocode_proc.stdin.flush()

        result = self.autocode_proc.stdout.readline()
        result = str(result, "UTF-8")
        print("Rx str: ",result)
        
        if(result == "1Done\n"):
            return result

        print("Got Data len: ",len(result))    
        if(len(result) != 0):
            result = loads(result)
            print("type: ", type(result))

            #result = result["Output"]
            #result = result["status"]
            if(result["status"] == "success"):
                print("=============================\n")
                print("Input: ",result["input"])

                result = result["predict"]
                print("op1: ",result["op1"])
                print("op2: ",result["op2"])
                print("op3: ",result["op3"])
                print("op4: ",result["op4"])
                print("op5: ",result["op5"])                                
                print("=============================\n")
                list1.append(result["op1"])  
                list1.append(result["op2"])  
                list1.append(result["op3"])  
                list1.append(result["op4"])  
                list1.append(result["op4"])
    
                completions = [
                    sublime.CompletionItem(
                        listToString(r),
                        annotation="abhishek-suggest",
                        completion="{}$0{}".format(
                                format_final_string(a,listToString(r)), ""
                            ),
                        completion_format=sublime.COMPLETION_FORMAT_SNIPPET,
                        kind=(
                            sublime.KIND_ID_COLOR_REDISH,
                            ATTRIBUTION_ELEMENT,
                            "22%",
                        ),
                    )
                    for r in list_predict
                ]
                return completions
        
    except (BrokenPipeError, IOError):
        print ('BrokenPipeError caught!!!', file = sys.stderr)
        # Python flushes standard streams on exit; redirect remaining output
        # to devnull to avoid another BrokenPipeError at shutdown
        devnull = os.open(os.devnull, os.O_WRONLY)
        os.dup2(devnull, sys.stdout.fileno())
        sys.exit(1)  # Python exits with error code 1 on EPIPE        
"""

def syntax_dummy(a):
    """
    count = 0
    list1 = []

    conn.send(a)

    msg = conn.recv()
    print("--->")
    print(msg)
    li = msg.splitlines()
    print("Received --->")
    for lines in li:
        print (lines)
        if (count >= 5):
            break
        list1.append(lines)
        count = count + 1
    for lines in list1:
    	print("Lines:",lines)
    	
    print("Setting outout")
    """
    list_predict= []
    list_predict.append("Dummy1")  
    list_predict.append("Dummy2")  
    list_predict.append("Dummy3")  
    list_predict.append("Dummy4")  
    list_predict.append("Dummy5")
    
    #list_predict = data_processing(p1, a)
    
    completions = [
        sublime.CompletionItem(
            listToString(r),
            annotation="abhishek-suggest",
            completion="{}$0{}".format(
                    format_final_string(a,listToString(r)), ""
                ),
            completion_format=sublime.COMPLETION_FORMAT_SNIPPET,
            kind=(
                sublime.KIND_ID_COLOR_REDISH,
                ATTRIBUTION_ELEMENT,
                "22%",
            ),
        )
        for r in list_predict
    ]
    

    return completions
    
###################################################################################
# Plugin Functions
###################################################################################
    
def plugin_loaded():
    print("\n\n******************************************")
    print("**  Abhishek's AutoCode Plugin Loading  **")    
    print("******************************************")
    print("Sublime Version     : %s" %(sublime.version()))
    print("Sublime Platform    : %s" %(sublime.platform()))
    print("Sublime Architecture: %s" %(sublime.arch()))    
    print("Sublime Channel     : %s" %(sublime.channel()))    
    print("AutoCode Plugin     : Version 4")
    print("Package Path        : %s" %(sublime.packages_path()))    
    print("Installed Package Path: %s" %(sublime.installed_packages_path()))
    print("******************************************\n\n")
    sublime.load_settings(PREFERENCES_PATH).set("auto_complete", True)

def plugin_unloaded():
    #conn.send('close connection')
    #conn.close()

    print("***Custom Plugin unloaded***")    
    
###################################################################################
# Sublime Plugin Function
###################################################################################

class AutoComplete(sublime_plugin.EventListener):

    def on_query_completions(self, view, prefix, locations):
        global keystroke
        if not all(view.match_selector(pt,"source.c") for pt in locations):
            print("Request Nothing for C File")
            return None
        contents = view.substr(sublime.Region(0, view.size()))        
        if(keystroke == "ctrl+space"):
            print("Prediction Command Issued")   
            pt = view.sel()[0].b
            line = view.line(pt)
            print("Input String: ",contents)
            return sublime.CompletionList(
                completions= autocode_proc.data_processing(contents) ,
                flags=sublime.DYNAMIC_COMPLETIONS | sublime.INHIBIT_REORDER,
            )
        else:
            return(syntax_dummy(contents),
                    sublime.INHIBIT_WORD_COMPLETIONS | sublime.INHIBIT_EXPLICIT_COMPLETIONS 
                    )

                
class OpenAutoCompletionCommand(sublime_plugin.TextCommand):

    def run(self, edit, **kargs):
        # print( "kargs: ", str( kargs ) )
        global keystroke
        view = self.view
        #print("Key Pressed:",kargs["keystroke"])
        keystroke = kargs["keystroke"]
        if(kargs["keystroke"] != "ctrl+space"):
            view.run_command("insert", {"characters": kargs["keystroke"]})
        else:
            view.run_command('auto_complete')


