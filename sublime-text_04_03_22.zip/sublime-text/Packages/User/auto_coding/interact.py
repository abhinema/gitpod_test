from transformers import GPT2LMHeadModel, GPT2Tokenizer
from multiprocessing.connection import Listener
import argparse
import transformers

import os
import platform

import subprocess
import sys
import time
from json import loads, dumps


transformers.logging.set_verbosity(transformers.logging.CRITICAL)


# Function to convert
def listToString(s):
	
	# initialize an empty string
	str1 = ""
	
	# traverse in the string
	for ele in s:
		str1 += ele
	
	# return string
	return str1

def compare_old_results(new, old):
    is_target_in_list = False
    #for i in new:
    target_string_lower = new.lower()
    old = listToString(old)
    #is_target_in_list = target_string_lower in (string.lower() for string in old)
    for string in old.splitlines():
        '''print("***********")
        print("New : ", new)
        print("old : ", string)
        print("***********")'''
        if(string.lower() == target_string_lower):
            is_target_in_list = True 
            break
        
    if(is_target_in_list == True):
        return True
    else:
        return False  
        
        
def is_not_blank(s):
    return bool(s and not s.isspace())
    
def check_wrong_string(str):
    if(is_not_blank(str) == False):
        return True
    if (str.startswith("//") == True):
        return True        
    if (str.startswith("/*") == True):
        return True
    if (str.startswith("*/") == True):
        return True                        
    if (str.startswith(" */") == True):
        return True                
    if (str.startswith("/**") == True):
        return True        
    if (str.startswith("**") == True):
        return True                
    if (str.startswith(" *  ") == True):
        return True                
    if (str.startswith("*\ @") == True):
        return True
    if (str.startswith(" * @") == True):
        return True                
    else:
        return False
        
def lastWord(string):
   
    # split by space and converting
    # string to list and
    lis = list(string.split(" "))
     
    # length of list
    length = len(lis)
     
    # returning last element in list
    return lis[length-1]        
                
def extract_line(gen, ori,num):
    cnt = 0
    '''if(len(ori.split('\n')) > 1):
        gen = gen.split(ori)'''
    diff = listToString(gen)
    #print("Len of ori string:",len(ori.split('\n')))
    #print("Len of gen string:",len(diff.split('\n')))
    last_line_ori = '\n'.join(context.splitlines()[-1:])

    for d1 in diff.splitlines():
        if((len(ori.split('\n')) -1)> (cnt)):
            #print("Not Running on: ", d1, "Cnt Val: ", cnt)
            cnt += 1
            continue
        if d1 in ori:
            #print("D1 atring found in original")
            continue            
        cnt += 1
        #print("Running on: ", d1)
        """if(cnt ==0):
            d1 = listToString(ori.splitlines()[-1:]) + d1
        cnt = 1"""
        #print("D1--->",d1)
        if(check_wrong_string(d1) == False):
            if(compare_old_results(d1, decoded_new) == False):
                
                #d1 = lastWord(listToString(ori.splitlines()[-1:]))+d1
                if(compare_old_results(d1, listToString(ori.splitlines()[-1:])) == True):
                    continue
                if "#include" in d1:    
                    if "#include" in last_line_ori:
                        #print("#Include Found")
                        #d1 = lastWord(d1)
                        d1 = d1.replace('#include ', '')
                        'This is to remove extra space after <HEADER.h>"_" '
                        d1, sep, tail = d1.partition(' ')  
                    else:
                        continue
                        
                elif "#define" in d1:    
                    if "#define" in last_line_ori:
                        #print("#Define Found")
                        #d1 = lastWord(d1)
                        d1 = d1.replace('#define ', '')
                    else:
                        continue


                head, sep, tail = d1.partition('//')
                d1 = head    
                #print("New Entry:",d1)
                
                #print(d1)
                if(compare_old_results(d1, decoded_new) == False):
                   d1 += '\n'
                   return d1
                else:
                   continue    
    else:
        return "Not Valid\n"

def set_data(sts_str,data_str):
    request = {
        "Output": {
            "status": sts_str,
            "op": data_str,
        }
    }
    return request

def set_predicted_data(state_str,
                       status_str,
                       input_str, 
                       op1_str,op2_str,op3_str,op4_str,op5_str):
    request = {
        "state": state_str,
        "status": status_str,
        "input" : input_str,
        "predict":{
            "op1": op1_str,
            "op2": op2_str,
            "op3": op3_str,
            "op4": op4_str,
            "op5": op5_str,                                                
        }
    }
    return request


'''
Working Good Medium:/home/abhi/Desktop/Code_repo/0_GPTSingleHead-20220209T023811Z-001/0_GPTSingleHead
small: /home/abhi/Desktop/Code_repo/0_GPTSingleHead_16-20220209T022253Z-001/0_GPTSingleHead_16
New Medium: /home/abhi/Desktop/Code_repo/0_GPTSingleHead_16-20220220T114529Z-001/0_GPTSingleHead_16
'''


if __name__ == '__main__':

    parser = argparse.ArgumentParser(description='Params')
    parser.add_argument('--model_path', type=str, default="/home/abhi/Desktop/Code_repo/0_GPTSingleHead_16-20220220T114529Z-001/0_GPTSingleHead_16",
                        help='the path to load fine-tuned model')
    parser.add_argument('--max_length', type=int, default=128,
                        help='maximum length for code generation')
    parser.add_argument('--temperature', type=float, default=0.7,
                        help='temperature for sampling-based code geneeration')
    parser.add_argument(
        "--use_cuda", default=True, action="store_true", help="inference with gpu?"
    )

    args = parser.parse_args()

    # load fine-tunned model and tokenizer from path
    
    model = GPT2LMHeadModel.from_pretrained(args.model_path)
    tokenizer = GPT2Tokenizer.from_pretrained(args.model_path)

    model.eval()
    if args.use_cuda:
        model.to("cuda")
    
    ''' Send Status'''

    val = dumps(set_data("Success\n"," "))
    val += "\n"
    sys.stdout.write(val)
    sys.stdout.flush()
    
    time.sleep(10)

    # now the fine-tunned model supports two programming languages, namely, python and java
    '''
    def lang_select():
        lang = ""
        while lang not in ["C", "C-Plus-Plus"]:
            print('Enter the programming language you prefer C or C-Plus-Plus')
            lang = input(">>> ").lower()
        return lang
    '''
    #sys.stdout.flush()    
    #lang = lang_select()
    lang = 'C'

    context = ""
    #listener = Listener(('localhost', 6000), authkey=b'secret password')
    #conn = listener.accept()
    #print('connection accepted from', listener.last_accepted)
    
    while context != "quit\n":
        decoded_new = ""
        # Recover Message from string 
        val = input()
        if not val:
            break
        req = loads(val)
        #print("Rx Val: ",file = sys.stderr )
        #print("Rx Val: ", req)
        result = req["Auto-Code"]
        req = result["stringchk"]
        context = ''.join(req)
        #context = ''.join(req.splitlines()[-1:])
        #print("Algo Input: ", dumps(context))
        if (context == "quit\n"):
            break

        else:
            """
            val = dumps(set_data("India", "Success"))
            val += "\n"
            sys.stdout.write(val)
            sys.stdout.flush()    
            """

            #if context == "change_lang":
            #    lang = lang_select()
            """
            #print(f"You are using {lang} now. Enter the context code")
            #context = input(">>> ")
            """
            input_ids = tokenizer.encode("<C> " + context,
                                         return_tensors='pt') if lang == "C" else tokenizer.encode(
                "<C-Plus-Plus> " + context, return_tensors='pt')
            '''
            outputs = model.generate(input_ids=input_ids.to("cuda") if args.use_cuda else input_ids,
                                     max_length=args.max_length,
                                     temperature=args.temperature,
                                     num_return_sequences=5)
            '''
            outputs = model.generate(input_ids=input_ids.to("cuda") if args.use_cuda else input_ids,
                                     max_length=args.max_length,
                                     temperature=args.temperature,
                                     num_beams=5,
                                     num_return_sequences=5)
            for i in range(5):
                decoded = tokenizer.decode(outputs[i], skip_special_tokens=True)
                #print("========================================================")
                #print("===Decoded===")
                #print(decoded)
                #print("=============")
                # ends with occurence of double new lines (to meet the convention of code completion)
                if "\n" in decoded:
                    decoded_new += extract_line(decoded, context,i)
                    #decoded_new += extract_line(decoded, ''.join(req.splitlines()[-1:]),i)
                else:
                    decoded_new += "DUMMY_"+ str(i)+"\n"
                #print('Generated {}: {}'.format(i, decoded_new))
            list1 = []
            predicted = decoded_new.splitlines()
            for lines in predicted:
                list1.append(lines)

            val = dumps(set_predicted_data("prediction","success",context,
                                          list1[0],list1[1],list1[2],list1[3],list1[4]))
            val += "\n"
            sys.stdout.write(val)
            sys.stdout.flush()    
            #print("========================================================")
            #for d1 in decoded_new.splitlines():
            #    print('Generated {}: {}'.format(i, d1))
            #print("========================================================")    

