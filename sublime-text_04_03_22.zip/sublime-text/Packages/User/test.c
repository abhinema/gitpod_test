#include <stdio.h>
#include <stdlib.h>

#define MAX(A,B) (((a) > (b))? (a) : (b))

int main(void)
{
	int a = 10, b = 5;
	int c = MAX(a, b);
	printf(	 "Maximum %d!\n", c);
	return 0;
}